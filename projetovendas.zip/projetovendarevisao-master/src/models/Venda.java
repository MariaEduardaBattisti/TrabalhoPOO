package models;

import repositorios.Repositorio;

import java.time.LocalDate;
import java.util.List;

public class Venda implements Repositorio {
    private LocalDate dataVenda;
    private Cliente cliente;
    private Funcionario funcionario;
    private List<Produto> produtos;

    public LocalDate getDataVenda() {
        return dataVenda;
    }

    public void setDataVenda(LocalDate dataVenda) {
        this.dataVenda = dataVenda;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Funcionario getFuncionario() {
        return funcionario;
    }

    public void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
    }

    public List<Produto> getProdutos() {
        return produtos;
    }

    public void setProdutos(List<Produto> produtos) {
        this.produtos = produtos;
    }

    @Override
    public void salvar() {
        System.out.println("Salvando venda" + this.cliente.getNome());
    }

    @Override
    public void alterar() {
        System.out.println("Alterar venda" + this.cliente.getNome());
    }

    @Override
    public void excluir() {
        System.out.println("Excluir venda" + this.cliente.getNome());
    }

    @Override
    public void listar() {
        System.out.println("Listar venda" + this.cliente.getNome());
    }
}
