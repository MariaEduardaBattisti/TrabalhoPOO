package telas;

import repositorios.Repositorio;

public class TelaCrud {

    private final Repositorio repositorio;

    // Método construtor
    // Toda vez que for criar uma instância de TelaCrud (new TelaCrud()), deve passar neste construtor.
    public TelaCrud(Repositorio repositorio) {
        this.repositorio = repositorio;
    }

    public void salvar() {
        this.repositorio.salvar();
    }

    public void excluir() {
        this.repositorio.excluir();
    }

    public void listar() {
        this.repositorio.listar();
    }

    public void alterar() {
        this.repositorio.alterar();
    }

}
