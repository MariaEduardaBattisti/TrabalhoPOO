import models.Cliente;
import models.Venda;
import repositorios.ClienteRepoisorioImpl;
import repositorios.FuncionarioRepositorioImpl;
import repositorios.ProdutoRepositorioImpl;
import telas.TelaCrud;

public class Main {
    public static void main(String[] args) {
        // Criação do objeto que representa a tela de CRUD, nesta intância nos passamos FuncionarioRepositorioImpl por
        // parâmetro no construtor.
        TelaCrud telaCrudFuncionario = new TelaCrud(new FuncionarioRepositorioImpl());
        telaCrudFuncionario.salvar();
        telaCrudFuncionario.excluir();
        telaCrudFuncionario.alterar();
        telaCrudFuncionario.listar();

        System.out.println("==========================================================================");

        // Criação do objeto que representa a tela de CRUD, nesta intância nos passamos ClienteRepoisorioImpl por
        // parâmetro no construtor.
        TelaCrud telaCrudCliente = new TelaCrud(new ClienteRepoisorioImpl());
        telaCrudCliente.salvar();
        telaCrudCliente.excluir();
        telaCrudCliente.alterar();
        telaCrudCliente.listar();

        System.out.println("==========================================================================");
        // Criação do objeto que representa a tela de CRUD, nesta intância nos passamos ProdutoRepositorioImpl por
        // parâmetro no construtor.
        TelaCrud telaCrudProduto = new TelaCrud(new ProdutoRepositorioImpl());
        telaCrudProduto.salvar();
        telaCrudProduto.excluir();
        telaCrudProduto.alterar();
        telaCrudProduto.listar();

        System.out.println("==========================================================================");

        Cliente cliente = new Cliente(500, "Lucas", "123123", "asdsdf");
        Venda venda = new Venda();
        venda.setCliente(cliente);

        TelaCrud telaVenda = new TelaCrud(venda);
        telaVenda.salvar();
        telaVenda.excluir();
        telaVenda.alterar();
        telaVenda.listar();
    }
}