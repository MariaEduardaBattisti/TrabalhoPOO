package repositorios;

public class ProdutoRepositorioImpl implements Repositorio{
    @Override
    public void salvar() {
        System.out.println("Salvando produto");
    }

    @Override
    public void alterar() {
        System.out.println("Alterando produto");
    }

    @Override
    public void excluir() {
        System.out.println("Excluindo produto");
    }

    @Override
    public void listar() {
        System.out.println("Listando prodoto");
    }
}
